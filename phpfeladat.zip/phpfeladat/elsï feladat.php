<?php
	for ($x=1; $x <= 10; $x++) {
        echo "<br>";
		for ($y=1; $y <= 10; $y++) {
		   $a = $y * $x;
		   echo $a . " ";
           
		   	}
		}
?>
