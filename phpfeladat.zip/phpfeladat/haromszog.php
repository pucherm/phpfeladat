<?php
function myfunc(){
if(isset($_POST['submit'])){
$a = $_POST['a'];
$b = $_POST['b'];
$c = $_POST['c'];
$alfa = $_POST['alfa'];
$beta = $_POST['beta'];
$gamma = $_POST['gamma'];
if (($a + $b > $c) && ($a + $c > $b) && ($b + $c > $a)) {
    echo "Megszerkeszthető!";
} else{
    echo "Nem szerkeszthető meg!";
    }
    if($alfa==90 OR $beta==90 OR $gamma==90){
        echo "Derékszögű";
    }
    if($alfa>90 OR $beta>90 OR $gamma>90){
        echo "Tompaszögű";
    }
    if($alfa<90 && $beta<90 && $gamma<90){
        echo "Hegyesszögű";
    }
    }
}
myfunc();
?>

<!doctype html>
<html>
<head>
    <body>
    <form action="" method="post">
    <input type="text" name="a" placeholder="A oldal">
    <input type="text" name="b" placeholder="B oldal">
    <input type="text" name="c" placeholder="C oldal">
    <input type="text" name="alfa" placeholder="Alfa szög">
    <input type="text" name="beta" placeholder="Béta szög">
    <input type="text" name="gamma" placeholder="Gamma szög">
    <button name="submit" type="submit">Elküld</button>
    </form>
    </body>
    </head>
</html>