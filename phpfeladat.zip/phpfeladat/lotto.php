<?php

/*
Akkor csinálj, lottósat, legyen olyan hogy beírsz 5 számot (ezek a tippjeid), generáljon a program 5 random számot (amik szerepelhetnek az 5-ös lottóban) nézd meg hány találat van és azok alapján adj vissza egy értéket hogy mennyir nyert az emberünk. A főnyeremény legyen mindjuk 320 millió ft és ebből legyen százalékosítva
*/

if(isset($_POST['submit'])){
    $elso = $_POST['elso'];
    $masodik = $_POST['masodik'];
    $harmadik = $_POST['harmadik'];
    $negyedik = $_POST['negyedik'];
    $otodik = $_POST['otodik'];
}
for($x=0;$x<5;$x++){
    $random = rand(1,90);
    echo $random;
    echo " ";
    }


?>
<!doctype html>
<html>
<head>
    <body>
    <form action="" method="post">
    <input type="text" name="elso" placeholder="Első">
    <input type="text" name="masodik" placeholder="Második">
    <input type="text" name="harmadik" placeholder="Harmadik">
    <input type="text" name="negyedik" placeholder="Negyedik">
    <input type="text" name="otodik" placeholder="Ötödik">
    <button name="submit" type="submit">Elküld</button>
    </form>
    </body>
    </head>
</html>